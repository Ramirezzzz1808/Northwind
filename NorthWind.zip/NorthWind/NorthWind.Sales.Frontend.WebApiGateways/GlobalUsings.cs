﻿global using NorthWind.Sales.Entities.Dtos.CreateOrder;
global using NorthWind.Sales.Entities.ValueObjects;
global using NorthWind.Sales.Frontend.BusinessObjects.Interfaces;
global using NorthWind.HttpDelegatingHandlers;