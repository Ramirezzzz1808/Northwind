﻿global using Microsoft.Extensions.DependencyInjection;
global using NorthWind.Membership.Entities.Dtos.UserRegistration;
global using NorthWind.Membership.Entities.Validators.UserRegistration;
global using NorthWind.Validation.Entities.Abstractions;
global using NorthWind.Validation.Entities.Interfaces;
global using NorthWind.Membership.Entities.Dtos.UserLogin;
global using NorthWind.Membership.Entities.Validators.UserLogin;