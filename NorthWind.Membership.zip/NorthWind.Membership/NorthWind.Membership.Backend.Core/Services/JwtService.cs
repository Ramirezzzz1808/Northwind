﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NorthWind.Membership.Backend.Core.Dtos;
using NorthWind.Membership.Backend.Core.Options;

namespace NorthWind.Membership.Backend.Core.Services;

internal class JwtService(IOptions<JwtOptions> options)
{
    SigningCredentials GetSigningCredentials()
    {
        var Key = Encoding.UTF8.GetBytes(options.Value.SecurityKey);
        var Secret = new SymmetricSecurityKey(Key);
        return new SigningCredentials(Secret, SecurityAlgorithms.HmacSha256);
    }

    List<Claim> GetClaims(UserDto userDto) =>
    [
        new Claim(ClaimTypes.Name, userDto.Email),
        new Claim("FullName", $"{userDto.FirstName} {userDto.LastName}")
    ];

    SecurityTokenDescriptor GetTokenDescriptor(
        SigningCredentials signingCredentials, List<Claim> claims) =>
        new SecurityTokenDescriptor
        {
            Issuer = options.Value.ValidIssuer,
            Audience = options.Value.ValidAudience,
            Expires = DateTime.UtcNow.AddMinutes(options.Value.ExpireInMinutes),
            SigningCredentials = signingCredentials,
            Subject = new ClaimsIdentity(claims)
        };

    public string GetToken(UserDto userDto)
    {
        var SigningCredentials = GetSigningCredentials();
        var Claims = GetClaims(userDto);
        var TokenDescriptor = GetTokenDescriptor(SigningCredentials, Claims);

        var TokenHandler = new JwtSecurityTokenHandler();
        var Token = TokenHandler.CreateToken(TokenDescriptor);
        return TokenHandler.WriteToken(Token);
    }
}